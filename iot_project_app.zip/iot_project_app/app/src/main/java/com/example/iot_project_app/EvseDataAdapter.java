package com.example.iot_project_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// necessary adapter to create rows inside the table of EvseSearchResult activity
public class EvseDataAdapter extends RecyclerView.Adapter<EvseDataAdapter.ViewHolder> {

    Context context;
    List<EvseDataModel> evse_list;

    public EvseDataAdapter(Context context, List<EvseDataModel> evse_list){
        this.context = context;
        this.evse_list = evse_list;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if(evse_list != null && evse_list.size() > 0){
            EvseDataModel model = evse_list.get(position);
            holder.cs_id_tv.setText(model.getCs_id());
            holder.evse_id_tv.setText(model.getEvse_id());
            holder.position_tv.setText(model.getPosition());
            holder.distance_tv.setText(model.getDistance());
        }
    }

    @Override
    public int getItemCount() {
        return evse_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView cs_id_tv, evse_id_tv, position_tv, distance_tv;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cs_id_tv = itemView.findViewById(R.id.cs_id_tv);
            evse_id_tv = itemView.findViewById(R.id.evse_id_tv);
            position_tv = itemView.findViewById(R.id.position_tv);
            distance_tv = itemView.findViewById(R.id.distance_tv);
        }
    }
}
