package com.example.iot_project_app;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;

public class EvsePay extends AppCompatActivity {

    // --------- declare variables ----------
    private TextView titleView;
    private TextView statusView;
    private Button payButton;
    private Button homeButton;
    private FirebaseAuth auth;
    private FirebaseUser currentUser;
    private String uid;
    private FirebaseDatabase database;
    private static final String FIREBASE_DATABASE_URL = "https://iotprojectfirebase-c5a62-default-rtdb.firebaseio.com/";
    private static final String TAG = EvsePay.class.getSimpleName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evse_pay);

        // --------- initialize variables ----------
        titleView = findViewById(R.id.titleViewEvsePay);
        statusView = findViewById(R.id.statusViewEvsePay);
        payButton = findViewById(R.id.payButtonEvsePay);
        homeButton = findViewById(R.id.homeButtonEvsePay);
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();
        uid = auth.getUid();
        database = FirebaseDatabase.getInstance(FIREBASE_DATABASE_URL);
        Intent intent = getIntent();
        String evse_code = intent.getStringExtra("evse_code");
        titleView.setText("EVSE: "+evse_code);



        // --- check and show the evse status
        database.getReference(evse_code+"/status").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e(TAG, "Error getting data", task.getException());
                } else {
                    String status = String.valueOf(task.getResult().getValue());
                    if (status.equals("free"))
                        statusView.setText("is available");
                    else if (status.equals("maintain"))
                        statusView.setText("is in maintenance");
                    else if(status.equals(uid)) {
                        // go to evse commands page
                        Intent intent = new Intent(getApplicationContext(), com.example.iot_project_app.EvseCommands.class);
                        intent.putExtra("evse_code", evse_code);
                        startActivity(intent);
                        finish();
                    }
                    else
                        statusView.setText("is busy");
                }
            }
        });



        // --------- set listeners ----------

        // make the evse occupied by the user and update the last command such that it signals the evse
        payButton.setOnClickListener(view ->  {
            database.getReference(evse_code).runTransaction(new Transaction.Handler() {
                @NonNull
                @Override
                public Transaction.Result doTransaction(@NonNull MutableData mutableData) {
                    String status = mutableData.child("status").getValue(String.class);
                    if(status != null && status.equals("free")) {
                        // set the evse occupied by the current user
                        mutableData.child("status").setValue(uid);
                        // insert as last_command/evse_code the evse on which the user is interacting with
                        FirebaseDatabase.getInstance().getReference().child("last_command/evse_code").setValue(evse_code)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d(TAG, "Updating last_command/evse_code successfully");
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e(TAG, "Updating last_command/evse_code failed");
                                    }
                                });
                        // insert as last_command/command the command count
                        FirebaseDatabase.getInstance().getReference().child("last_command/command").setValue("count")
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d(TAG, "Updating last_command/command successfully");
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e(TAG, "Updating last_command/command failed");
                                    }
                                });
                    }
                    return Transaction.success(mutableData);
                }

                @Override
                public void onComplete(@Nullable DatabaseError error, boolean committed, @Nullable DataSnapshot currentData) {
                    String status = (String) currentData.child("status").getValue();
                    // if the evse has been taken by the current user then show him the commands page
                    if(status.equals(uid)) {
                        // go to evse commands page
                        Intent intent = new Intent(getApplicationContext(), EvseCommands.class);
                        intent.putExtra("evse_code", evse_code);
                        startActivity(intent);
                        finish();
                    }
                    else
                        Toast.makeText(EvsePay.this, "The evse is busy or unavailable", Toast.LENGTH_LONG).show();
                }
            });
        });

        homeButton.setOnClickListener(view ->  {
            Intent intent2 = new Intent(getApplicationContext(), HomePage.class);
            startActivity(intent2);
            finish();
        });
    }
}