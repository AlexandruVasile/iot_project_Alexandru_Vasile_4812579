package com.example.iot_project_app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

public class EvseCommands extends AppCompatActivity {

    // --------- declare variables ----------
    private TextView titleView;
    private TextView statusView;
    private Button commandButton;
    protected String currentCommand;
    private FirebaseAuth auth;
    private FirebaseUser currentUser;
    private String uid;
    private FirebaseDatabase database;
    private DatabaseReference valueRef;
    private ValueEventListener listener;
    private static final String FIREBASE_DATABASE_URL = "https://iotprojectfirebase-c5a62-default-rtdb.firebaseio.com/";
    private static final String CHANNEL_ID = "Your channel id";
    private static final String CHANNEL_NAME = "Your channel name";
    private static final String CHARGING_COMPLETED = "100";
    private static final String COUNTING_COMPLETED = "0";
    private static final String MAINTENANCE = "-42";
    private static final String DEFAULT_VALUE = "-1";
    private static final int NOTIFICATION_INTERVAL = 20;
    private static final String TAG = EvseCommands.class.getSimpleName();
    private int number = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evse_commands);

        // --------- initialize variables ----------
        titleView = findViewById(R.id.titleViewEvseCommands);
        statusView = findViewById(R.id.statusViewEvseCommands);
        commandButton = findViewById(R.id.commandButtonEvseCommands);
        currentCommand = null;
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();
        uid = auth.getUid();
        database = FirebaseDatabase.getInstance(FIREBASE_DATABASE_URL);
        Intent intent = getIntent();
        String evse_code = intent.getStringExtra("evse_code");
        titleView.setText("EVSE: " + evse_code);

        // create a notification channel
        int importance = NotificationManager.IMPORTANCE_DEFAULT;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance);
        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(channel);


        // --------- set listeners ----------

        // manage what happens when start or stop button is clicked
        commandButton.setOnClickListener(view -> {
            currentCommand = commandButton.getText().toString();
            // update the last_command entry in the firebase db
            database.getReference("last_command").runTransaction(new Transaction.Handler() {
                @NonNull
                @Override
                public Transaction.Result doTransaction(@NonNull MutableData last_command) {
                    last_command.child("evse_code").setValue(evse_code);
                    last_command.child("command").setValue(currentCommand);
                    return Transaction.success(last_command);
                }

                @Override
                public void onComplete(@Nullable DatabaseError error, boolean committed, @Nullable DataSnapshot currentData) {

                    // if start was clicked show the next command, that is stop
                    if (currentCommand.equals("start"))
                        commandButton.setText("stop");

                    // if stop was clicked, free the evse
                    else if (currentCommand.equals("stop")) {
                        // make the evse free
                        database.getReference().child(evse_code + "/status").setValue("free")
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d(TAG, "Evse has been set free successfully");
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e(TAG, "Error in setting free the evse");
                                    }
                                });

                        // reset the last command
                        resetLastCommand();

                        // go to home page
                        Intent intent = new Intent(getApplicationContext(), HomePage.class);
                        startActivity(intent);
                        finish();
                    }
                } // end of onComplete method
            });// end of transaction on last_command
        });// end of commandButton.setOnClickListener


        // listener on the values emitted by the evse
        valueRef = database.getReference(evse_code+"/value");
        listener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String value = snapshot.getValue().toString();

                    // if the time to press start is over then make the evse available
                    if (value.equals(COUNTING_COMPLETED)) {
                        database.getReference(evse_code+"/status").setValue("free")
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d(TAG, "Evse freed after counting has finished");
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.d(TAG, "Error in making the evse freed after counting has finished");
                                    }
                                });

                        // reset the last command
                        resetLastCommand();

                        // then refund the user
                        Intent intent = new Intent(getApplicationContext(), EvseRefund.class);
                        intent.putExtra("reason", "count");
                        startActivity(intent);
                        finish();
                    } // if the charging is completed entirely
                    else if(value.equals(CHARGING_COMPLETED)){
                        database.getReference(evse_code+"/status").setValue("free")
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d(TAG, "Evse freed successfully after charging was completed entirely");
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e(TAG, "Error! Evse wasn't freed successfully after charging was completed entirely");
                                    }
                                });

                        // reset the last command
                        resetLastCommand();

                        // create the notification about the completion of the charging
                        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID)
                                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                                .setContentTitle("Notification")
                                .setContentText("The charging is complete!");

                        // emit the notification
                        notificationManager.notify(0, mBuilder.build());
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                // nothing
                            }
                        }, 3000);   // to give time to send the notification

                        // comeback to homepage
                        Intent intent = new Intent(getApplicationContext(), HomePage.class);
                        startActivity(intent);
                        finish();
                    }
                    else if(value.equals(DEFAULT_VALUE)){
                        // ignore the default value
                        statusView.setText("");
                    }
                    else if(value.equals(MAINTENANCE)){
                        database.getReference(evse_code+"/status").setValue("maintain")
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d(TAG, "The status of the evse has been set in maintenance");
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e(TAG, "Error! The status of the evse hasn't been set in maintenance");
                                    }
                                });

                        // reset the last command
                        resetLastCommand();

                        // refund the user since the maintenance has started while he was using the evse
                        Intent intent = new Intent(getApplicationContext(), EvseRefund.class);
                        intent.putExtra("reason", "maintenance");
                        startActivity(intent);
                        finish();
                    }

                    else {
                        if(Integer.parseInt(value) % NOTIFICATION_INTERVAL == 0) {

                            // build notification
                            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID)
                                    .setSmallIcon(android.R.drawable.sym_def_app_icon)
                                    .setContentTitle("Notification")
                                    .setContentText("The charging is at "+value);

                            // emit the notification
                            notificationManager.notify(0, mBuilder.build());
                        }
                        // just publish the percentage or the count
                        else{
                            // if the charge hasn't started then the value means count
                            if(currentCommand ==null)
                                statusView.setText("Time remained to press start " + value);
                            else
                                statusView.setText("         Charging percentage " + value);
                        }
                    }

                } else
                    Log.d(TAG, "counter or percentage value wasn't received");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.d(TAG, "onCancelled has been triggered!");
            }};
        valueRef.addValueEventListener(listener);
    }

    private void resetLastCommand() {
        database.getReference("last_command").runTransaction(new Transaction.Handler() {
            @NonNull
            @Override
            public Transaction.Result doTransaction(@NonNull MutableData last_command) {
                last_command.child("evse_code").setValue("none");
                last_command.child("command").setValue("none");
                return Transaction.success(last_command);
            }

            @Override
            public void onComplete(@Nullable DatabaseError error, boolean committed, @Nullable DataSnapshot currentData) {
                Log.d(TAG, "transaction about resetting the last_command completed");
            }
        });
    }

    @Override
    protected void onStop() {
        // Call the superclass method first.
        super.onStop();
        valueRef.removeEventListener(listener);
        Log.d("ciao1", "ciao2");
    }
}