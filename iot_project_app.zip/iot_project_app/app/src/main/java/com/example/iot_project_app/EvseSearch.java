package com.example.iot_project_app;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.List;

public class EvseSearch extends AppCompatActivity {

    // --------- declare variables ----------
    private TextInputEditText currentTypeView;
    private TextInputEditText connectorTypeView;
    private TextInputEditText latitudeView;
    private TextInputEditText longitudeView;
    private Button searchButton;
    private Button homeButton;
    private FirebaseUser currentUser;
    private FirebaseAuth auth;
    private static final int PERMISSION_REQUEST_CODE = 200;
    private static final String DEFAULT_CONNECTOR_TYPE = "1";
    private static final String DEFAULT_CURRENT_TYPE = "AC";
    private static final double DEFAULT_LATITUDE = 44.406693;
    private static final double DEFAULT_LONGITUDE = 8.946916;
    private LocationManager mLocationManager = null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evsesearch);

        // --------- initialize variables ----------
        connectorTypeView = findViewById(R.id.connectorTypeViewEvseSearch);
        connectorTypeView.setText(DEFAULT_CONNECTOR_TYPE);
        currentTypeView = findViewById(R.id.currentTypeViewEvseSearch);
        currentTypeView.setText(DEFAULT_CURRENT_TYPE);
        latitudeView = findViewById(R.id.latitudeSearchEvse);
        latitudeView.setText(Double.toString(DEFAULT_LATITUDE));
        longitudeView = findViewById(R.id.longitudeViewEvseSearch);
        longitudeView.setText(Double.toString(DEFAULT_LONGITUDE));
        searchButton = findViewById(R.id.searchButtonEvseSearch);
        homeButton = findViewById(R.id.homeButtonEvseSearch);
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();

        // request gps position
        requestPermission();

        // --------- set listeners ----------
        homeButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), HomePage.class);
            startActivity(intent);
            finish();
        });

        searchButton.setOnClickListener(view -> {
            // get the content from the views
            String current_type = currentTypeView.getText().toString();
            String connector_type = connectorTypeView.getText().toString();
            String latitude = latitudeView.getText().toString();
            String longitude = longitudeView.getText().toString();

            // send the content to the EvseSearchResult activity
            Intent intent = new Intent(getApplicationContext(), EvseSearchResult.class);
            intent.putExtra("current_type", current_type);
            intent.putExtra("connector_type", connector_type);
            intent.putExtra("latitude", latitude);
            intent.putExtra("longitude", longitude);
            startActivity(intent);
            finish();
        });
    }


    private void getGpsPosition(LocationManager mLocationManager, TextInputEditText latitudeView, TextInputEditText longitudeView) {
        mLocationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
        List<String> providers = mLocationManager.getProviders(true);
        Location bestLocation = null;

        // get the best position provider
        for (String provider : providers) {
            @SuppressLint("MissingPermission") Location l = mLocationManager.getLastKnownLocation(provider);
            if (l == null)
                continue;
            if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy())
                bestLocation = l;

        }

        // update the views related to the position with the gps position
        latitudeView.setText(Double.toString(bestLocation.getLatitude()));
        longitudeView.setText(Double.toString(bestLocation.getLongitude()));
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean fineLocationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean coarseLocationAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    // if both permissions are allowed then get the gps position
                    if (fineLocationAccepted && coarseLocationAccepted) {
                        Toast.makeText(EvseSearch.this, "Permission Granted, you can use your gps position in the search", Toast.LENGTH_LONG).show();
                        getGpsPosition(mLocationManager, latitudeView, longitudeView);
                    }
                    else {
                        Toast.makeText(EvseSearch.this, "Permission Denied, so you can't use your gps position in the search", Toast.LENGTH_LONG).show();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                                showMessageOKCancel("You need to allow access to gps permissions to use it in the search",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION},
                                                            PERMISSION_REQUEST_CODE);
                                                }
                                            }
                                        });
                                return;
                            }
                        }
                    }
                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(EvseSearch.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }
}