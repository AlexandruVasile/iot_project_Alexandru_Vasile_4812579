package com.example.iot_project_app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EvseSearchResult extends AppCompatActivity {

    // --------- declare variables ----------
    private String connector_type;
    private String current_type;
    private String latitude;
    private String longitude;
    private Button homeButton;
    private FirebaseUser currentUser;
    private FirebaseAuth auth;
    private RequestQueue requestQueue;
    private JSONArray response;
    private RecyclerView recycler_view;
    private EvseDataAdapter adapter;
    private static final String URL = "http://localhost:1880/search";
    private static final String TAG = EvseSearchResult.class.getSimpleName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchevseresult);

        // --------- initialize variables ----------
        Intent intent1 = getIntent();
        connector_type = intent1.getStringExtra("connector_type");
        current_type = intent1.getStringExtra("current_type");
        latitude = intent1.getStringExtra("latitude");
        longitude = intent1.getStringExtra("longitude");
        homeButton = findViewById(R.id.homeButtonEvseSearchResult);
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();

        // --------- set listeners ----------
        homeButton.setOnClickListener(view ->  {
            Intent intent2 = new Intent(getApplicationContext(), HomePage.class);
            startActivity(intent2);
            finish();
        });

        // create the http post request
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                resp -> {
                    try {
                        response = new JSONArray(resp);
                        recycler_view = findViewById(R.id.recycler_view);
                        setRecyclerView();
                    } catch (JSONException e) {
                        Log.d(TAG, "Error in converting the response from string to json");
                        Toast.makeText(EvseSearchResult.this, "Error try again later", Toast.LENGTH_LONG).show();
                        return;
                    }
                },
                error -> {
                    Toast.makeText(EvseSearchResult.this, "Error try again later", Toast.LENGTH_LONG).show();
                    Log.d(TAG, "There has been an error in receiving the response");
                    return;
                })
        {
            // add parameters to the post request
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("cur_type", current_type);
                params.put("type", connector_type);
                params.put("lat", latitude);
                params.put("lon", longitude);
                return params;
            }
        };
        requestQueue = Volley.newRequestQueue(EvseSearchResult.this);
        requestQueue.add(stringRequest);
    }

    // set the table
    private void setRecyclerView() {
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EvseDataAdapter(this, createRows());
        recycler_view.setAdapter(adapter);
    }

    // create the rows of the table
    private List<EvseDataModel> createRows() {
        List<EvseDataModel> row_list = new ArrayList<>();

        // iterate through the received json array and populate the rows
        for (int i = 0; i < response.length(); i++) {
            JSONObject row = null;
            try {
                row = response.getJSONObject(i);
            } catch (JSONException e) {
                Toast.makeText(EvseSearchResult.this, "Error try again later", Toast.LENGTH_LONG).show();
                return null;
            }
            String cs_id, evse_id, position_name, distance_km;
            try {
                cs_id = row.getString("cs_id");
                evse_id = row.getString("evse_id");
                position_name = row.getString("position_name");
                distance_km = row.getString("distance_km");
            } catch (JSONException e) {
                Toast.makeText(EvseSearchResult.this, "Error try again later", Toast.LENGTH_LONG).show();
                return null;
            }
            row_list.add(new EvseDataModel(cs_id, evse_id, position_name, distance_km));
        }
        return row_list;
    }
}