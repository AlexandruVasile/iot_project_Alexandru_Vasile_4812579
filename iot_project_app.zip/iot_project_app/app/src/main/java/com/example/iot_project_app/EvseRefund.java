package com.example.iot_project_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EvseRefund extends AppCompatActivity {

    // --------- declare variables ----------
    private TextView reasonMessageView;
    private TextView refundMessageView;
    private Button homeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evse_refund);

        // --------- initialize variables ----------
        reasonMessageView = findViewById(R.id.reasonMessageViewEvseRefund);
        refundMessageView = findViewById(R.id.refundMessageViewEvseRefund);
        homeButton = findViewById(R.id.homeButtonEvseRefund);

        Intent intent1 = getIntent();
        String reason = intent1.getStringExtra("reason");
        if(reason.equals("count"))
            reasonMessageView.setText("(You didn't press the start button in time)");
        else if(reason.equals("maintenance"))
            reasonMessageView.setText("A maintenance has started");

        // --------- set listeners ----------
        homeButton.setOnClickListener( view ->  {
            Intent intent2 = new Intent(getApplicationContext(), HomePage.class);
            startActivity(intent2);
            finish();
        });
    }
}