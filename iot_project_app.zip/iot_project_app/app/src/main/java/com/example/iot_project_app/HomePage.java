package com.example.iot_project_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class HomePage extends AppCompatActivity {

    // --------- declare variables ----------
    private Button logoutButton;
    private Button searchEvseButton;
    private Button okButton;
    private TextInputEditText insertEvseCodeView;
    private FirebaseUser currentUser;
    private FirebaseAuth auth;
    private FirebaseDatabase database;
    private DatabaseReference myRef;
    private RequestQueue requestQueue;
    private static final String FIREBASE_DATABASE_URL = "https://iotprojectfirebase-c5a62-default-rtdb.firebaseio.com/";
    private static final String URL = "http://localhost:1880/check_evse_code";
    private static final String TAG = HomePage.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        // --------- initialize variables ----------
        logoutButton = findViewById(R.id.logoutButtonHomePage);
        searchEvseButton = findViewById(R.id.searchEvseButtonHomePage);
        okButton = findViewById(R.id.okButtonHomePage);
        insertEvseCodeView = findViewById(R.id.insertEvseCodeViewHomePage);
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();
        database = FirebaseDatabase.getInstance(FIREBASE_DATABASE_URL);

        // --------- set listeners ----------
        logoutButton.setOnClickListener(view ->  {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        });

        okButton.setOnClickListener(view ->  {
            String evseCode = insertEvseCodeView.getText().toString();

            // check if the inserted evse exists
            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, // create the http post request
                    response ->
                    {
                        String resp = response;
                        // if exists go on the evse page
                        if(resp.equals("1")){
                            Intent intent = new Intent(getApplicationContext(), EvsePay.class);
                            intent.putExtra("evse_code", evseCode);
                            startActivity(intent);
                            finish();
                        }
                        else {
                            Toast.makeText(HomePage.this, "The inserted evse is not available", Toast.LENGTH_LONG).show();
                        }
                    },
                    error -> Toast.makeText(HomePage.this, "Error try again later", Toast.LENGTH_LONG).show())
            {
                // add parameters to the post request
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("evse_code", insertEvseCodeView.getText().toString());
                    return params;
                }
            };
            requestQueue = Volley.newRequestQueue(HomePage.this);
            requestQueue.add(stringRequest);

        });

        searchEvseButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), EvseSearch.class);
            startActivity(intent);
            finish();
        });
    }
}