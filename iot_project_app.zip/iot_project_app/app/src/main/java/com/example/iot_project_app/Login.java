package com.example.iot_project_app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {

    // --------- declare variables ----------
    private TextInputEditText emailView;
    private TextInputEditText passwordView;
    private Button okButton;
    private Button signUpButton;
    private FirebaseUser currentUser;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // --------- initialize variables ----------
        emailView = findViewById(R.id.emailViewLogin);
        passwordView = findViewById(R.id.passwordViewLogin);
        okButton = findViewById(R.id.okButtonLogin);
        signUpButton = findViewById(R.id.signUpButtonLogin);
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();

        // check if it's the first login after the registration
        Intent i = getIntent();
        boolean firstLogin = i.getBooleanExtra("firstLogin", false);

        // check if the user is already logged in
        if (currentUser != null && !firstLogin) {
            goHomePage(auth.getUid());
        }

        // --------- set listeners ----------
        okButton.setOnClickListener(view -> {
            String email, password;
            email = emailView.getText().toString();
            password = passwordView.getText().toString();

            // check if email or password is empty
            if (isEmailOrPasswordEmpty(email, password))
                return;

            // login
            auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(Login.this, "Login successful",
                                        Toast.LENGTH_SHORT).show();
                                goHomePage(auth.getUid());
                            }
                            else {
                                Toast.makeText(Login.this, "Login failed",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }); // end setOnClickListener of okView

        signUpButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Registration.class);
            startActivity(intent);
            finish();
        }); // end setOnClickListener of registerView
    }

    // --------- auxiliary methods ----------
    private boolean isEmailOrPasswordEmpty(String email, String password) {
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(Login.this, "no email provided", Toast.LENGTH_SHORT).show();
            return true;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(Login.this, "no password provided", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    private void goHomePage(String user){
        Intent intent = new Intent(getApplicationContext(), HomePage.class);
        intent.putExtra("uid", auth.getUid());
        Log.d("uid", auth.getUid());
        startActivity(intent);
        finish();
    }
}