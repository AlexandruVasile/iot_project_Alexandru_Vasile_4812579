package com.example.iot_project_app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Registration extends AppCompatActivity {

    // --------- declare variables ----------
    TextInputEditText emailView, passwordView;
    Button okButton, loginButton;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        // --------- initialize variables ----------
        emailView = findViewById(R.id.emailViewRegistration);
        passwordView = findViewById(R.id.passwordViewRegistration);
        okButton = findViewById(R.id.okButtonRegistration);
        loginButton = findViewById(R.id.loginButtonRegistration);
        auth = FirebaseAuth.getInstance();

        // --------- set listeners ----------
        loginButton.setOnClickListener(view -> {
            // go to login page
            Intent intent = new Intent(getApplicationContext(), com.example.iot_project_app.Login.class);
            startActivity(intent);
            finish();
        });

        okButton.setOnClickListener(view -> {
            String email, password;
            email = emailView.getText().toString();
            password = passwordView.getText().toString();

            // check if email or password is empty
            if (isEmailOrPasswordEmpty(email, password))
                return;

            // create the account
            auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful())
                            {
                                Toast.makeText(Registration.this, "Account created successfully.",
                                        Toast.LENGTH_SHORT).show();
                                String uid = auth.getUid();
                                // go to login page
                                Intent intent = new Intent(getApplicationContext(), com.example.iot_project_app.Login.class);
                                intent.putExtra("firstLogin", true);
                                startActivity(intent);
                                finish();
                            }
                            else
                                Toast.makeText(Registration.this, "Failed to create the account",
                                        Toast.LENGTH_SHORT).show();
                        } // end onComplete
                    }); // end OnCompleteListener
        }); // end onClickListener
    } // end onCreate

    // --------- auxiliary methods ----------
    private boolean isEmailOrPasswordEmpty(String email, String password) {
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(Registration.this, "no email provided", Toast.LENGTH_SHORT).show();
            return true;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(Registration.this, "no password provided", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }
}