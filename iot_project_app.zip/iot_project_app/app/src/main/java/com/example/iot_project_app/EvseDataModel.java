package com.example.iot_project_app;


// necessary model to create rows inside the table of EvseSearchResult activity
public class EvseDataModel {
    // each element will become a cell in a row
    String cs_id;
    String evse_id;
    String position;
    String distance;

    public EvseDataModel(String cs_id, String evse_id, String position, String distance) {
        this.cs_id = cs_id;
        this.evse_id = evse_id;
        this.position = position;
        this.distance = distance;
    }

    public String getCs_id() {
        return cs_id;
    }

    public String getEvse_id() {
        return evse_id;
    }

    public String getPosition() {
        return position;
    }

    public String getDistance() {
        return distance;
    }
}
