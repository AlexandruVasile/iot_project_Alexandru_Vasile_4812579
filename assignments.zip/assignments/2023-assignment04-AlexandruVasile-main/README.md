[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10734483&assignment_repo_type=AssignmentRepo)
# Assignment 4

## Node.js: stream transformers and pipelines

Consider the Node.js script that defines a [through transformer](https://www.npmjs.com/package/through2) for parsing a CSV file within a [pipe](https://nodejs.org/api/stream.html#stream_simplified_construction):
```js
const through2 = require('through2');
const fs = require('fs');
const split = require('split2');

const parseCSV = () => {
    let templateKeys = [];
    let parseHeadline = true;

    return through2.obj((data, enc, cb) => {       
      if (parseHeadline) {
        templateKeys = data.toString().split(',');
        parseHeadline = false;
        return cb(null, null);                    
      }

      const entries = data.toString().split(',');
      const obj = {};

      templateKeys.forEach((el, index) => {      
        obj[el] = entries[index];
      });

      return cb(null, obj);                       
    });
  };
```
and a CSV file `staff.csv`:
```
name,surname,country
John,Smith,UK
Carlo,Rossi,Italy
Fritz,Jung,Germany
...
```
1. 
   Create a node.js pipe to read each line of the `staff.csv`, transform them into objects using parseCSV, and redirect the surname field to stdout
   
   *Hint: Transformers can be applied in Node.js pipelines as follows:*
   ```js
   const stream = fs.createReadStream('staff.csv');
   stream.pipe(split()).pipe(parseCSV()) ....
   ```

1. Modify the `parseCSV()` function so as to create objects that contain only surname and country. Test the new transformer using the pipeline in 1.

1. Create an object transformer to add a `date` field to every object in the pipe. Test the new  pipeline in combination with `parseCSV()`.

1. Choose one of the protocols discussed in the lectures (tcp/http/coap) and create a server that applies transformers to process the input request.



