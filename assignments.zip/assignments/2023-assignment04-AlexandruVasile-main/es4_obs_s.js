const coap    = require('coap')
    , server  = coap.createServer()

server.on('request', (req, res) => {

    var interval = setInterval(function () {
      res.write(new Date().toISOString() + '\n')
    }, 1000)

    res.on('finish', function (err) {
      clearInterval(interval)
    })
  })
  
let myFilter = through2.obj(function (chunk, enc, callback) {
    if(parseHeadline){
		chunk.forEach((el, index) => {      
			templateKeys.push(el.trim());
		});
		parseHeadline = false;
	}
	else
	{
		const obj = {};
		chunk.forEach((el, index) => {
			if(templateKeys[index] === "surname" || templateKeys[index] === "country")
				obj[templateKeys[index]] = el;
		});
		// insert in the stream
		this.push(JSON.stringify(obj));
	}
    callback()
  });

server.listen(() => {
  console.log('server started')
})
