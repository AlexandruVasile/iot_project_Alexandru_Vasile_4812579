const through2 = require('through2');
const fs = require('fs');
const split = require('split2');
const stream = fs.createReadStream('staff.csv');
const csv = require('csv2')

//======[Es2]
let myFilter = through2.obj(function (chunk, enc, callback) {
    if(parseHeadline){
		chunk.forEach((el, index) => {      
			templateKeys.push(el.trim());
		});
		parseHeadline = false;
	}
	else
	{
		const obj = {};
		chunk.forEach((el, index) => {
			if(templateKeys[index] === "surname" || templateKeys[index] === "country")
				obj[templateKeys[index]] = el;
		});
		// insert in the stream
		this.push(JSON.stringify(obj));
	}
    callback()
  });
  
let parseHeadline = true;
let templateKeys = [];
stream.pipe(csv())
    .pipe(myFilter).pipe(process.stdout)


