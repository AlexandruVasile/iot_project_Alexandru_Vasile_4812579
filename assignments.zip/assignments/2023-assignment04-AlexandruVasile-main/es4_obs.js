const through2 = require('through2');
const coap  = require('coap')
    , req   = coap.request({
                observe: true
              })

req.on('response', function(res) {
  res.pipe(myFilter).pipe(process.stdout)
})

req.end()



let myFilter = through2.obj(function (chunk, enc, callback) {
    let obj = {};
    const decoder = new TextDecoder("utf-8");
    const text = decoder.decode(chunk);
    this.push("Hour: "+text.slice(11, 19)+"\n");
    
    callback()
  });


