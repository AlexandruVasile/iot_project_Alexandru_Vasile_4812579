[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10757849&assignment_repo_type=AssignmentRepo)
# Assignment 05

## Node.js: promises, `async`, `await`

### Exercise 1
Complete the code in `exercise.js` to implement a version of class `Reader` (see [assignment 3](https://classroom.github.com/a/YMn0dA0V)) based on promises.

*Hint*: think in terms of the control flow graph of callbacks and associated emitted events; define a recursive callback to implement the read loop.

### Exercise 2
Complete the code in `exercise.js` to implement a version of class `Reader` by implicitly using promises with `async`, `await`.
