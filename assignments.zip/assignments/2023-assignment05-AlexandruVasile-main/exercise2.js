'use strict';

const EventEmitter = require('events');
const fs = require('fs');
const { promisify } = require('util');
const [open, read, close] = [promisify(fs.open), promisify(fs.read), promisify(fs.close)];

const BUFF_SIZE = 2**2;

class Reader extends EventEmitter {
    // to be completed
    constructor(buffer_size) {
    	super();
    	this.buffer = Buffer.alloc(buffer_size==undefined ? BUFF_SIZE : buffer_size);
        this.alreadyReadOneFile = false;
	}

    async readLoop(fd) {
        const res = await read(fd, this.buffer);
        if(res.bytesRead > 0){
            this.emit('data', res.bytesRead, this.buffer);
            this.readLoop(fd)
        }
        else {
            close(fd);
            this.emit('close');
        }
    }

    async readFile(file){
        if(!this.alreadyReadOneFile){
            this.alreadyReadOneFile = true;
		    const fd = await open(file, 'r');
            this.emit('open'); 
            if (fd == -1){
                console.log("error at opening the file");
            }
            else
                this.readLoop(fd);
        }
    }
}

const r = new Reader();
r.readFile(process.argv[2] || 'test.txt');
r.once('error', console.error);
r.once('open', () => console.log('opened'));
r.on('data', (bytes, buf) => console.log(buf.toString('utf8', 0, bytes)));
r.once('close', () => console.log('closed'));

