'use strict';

const EventEmitter = require('events');
const fs = require('fs');
const { promisify } = require('util');
const [open, read, close] = [promisify(fs.open), promisify(fs.read), promisify(fs.close)];

const BUFF_SIZE = 2**2;

class Reader extends EventEmitter {
    // to be completed
    constructor(buffer_size) {
    	super();
    	this.buffer = Buffer.alloc(buffer_size==undefined ? BUFF_SIZE : buffer_size);
        this.flag = false;
        this.alreadyReadOneFile = false;
	}

    openFile(file) {
        return open(file, 'r');
    }

    print(fd, promise) {
        if(promise.bytesRead > 0)
        {
            this.emit('data', promise.bytesRead, this.buffer);
            this.readLoop(fd);
        }
        else{
            close(fd);
            this.emit('close');
        }
    }

    readLoop(fd) {
        if(this.flag == false){
            this.emit('open'); 
            this.flag = true;
        }
        read(fd, {buffer: this.buffer}).then((promise) => this.print(fd, promise));
    }

    readFile(file){
        if(!this.alreadyReadOneFile){
            this.alreadyReadOneFile = true;
		    this.openFile(file).then(this.readLoop.bind(this)).catch(console.error);
        }
    }
}

const r = new Reader();
r.readFile(process.argv[2] || 'test.txt');
r.once('error', console.error);
r.once('open', () => console.log('opened'));
r.on('data', (bytes, buf) => console.log(buf.toString('utf8', 0, bytes)));
r.once('close', () => console.log('closed'));

