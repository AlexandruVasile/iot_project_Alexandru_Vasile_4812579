'use strict';

const {open,read,write,close}=require('fs');
const BUFFER_SIZE=2*20; 
const buffer = Buffer.alloc(BUFFER_SIZE);
function handleError(err) {
    console.error('ERROR: ${err.code}(${err.message})');
}
function copy(rpath, wpath){
    open(rpath, 'r', (err, fdR) => { // callback about the open of the file to be read
        if (err) return handleError(err);
        open(wpath, 'w', (err, fdW) => { // callback about the open of the file to be written
            if (err) return handleError(err);
            const readLoop = () => { // function to read a file
                read(fdR, {buffer}, (err, bytesRead, buffer) => { // callback about the read of the file to be read
                    if (err) return handleError(err);
                    if (bytesRead > 0) { // if some bytes have been read then write them on the file to be written
                        write(fdW, buffer, 0, bytesRead, (err) => { // callback about the write of the file to be written
                            if (err) return handleError(err);
                            readLoop();
                        });
                    } else { // if there is nothing to read close all the two files
                        close(fdR, (err) => {
                            if (err) return handleError(err);
                        });
                        close(fdW, (err) => {
                            if (err) return handleError(err);
                        });
                    }
                });
            };
            readLoop();
        });
    });
}
copy(process.argv[2]||'in.txt',process.argv[3]||'out.txt');
