[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10540445&assignment_repo_type=AssignmentRepo)
# Assignment 2
## Node.js: modules `fs` and `http`

### Exercise 1
Complete file `exercise1.js` to define the `copy(rpath,wpath)` function which copies the file specified by path `rpath` into the file specified by
path `wpath`; to practice with asynchronous programming use **only** the imported functions `open`,
`read`, `write` and `close` and a buffer `buff` of fixed size `2**20`. 

*Warning*: `copy(rpath,wpath)` should work correctly with files of arbitrary size. 

*Hint*: use a recursive callback.

### Exercise 2
Complete file `exercise2.js` to define a Node.js HTTP server at `localhost:8080` able to manage the following requests:
#### GET requests with URL `/weather`
A table in JSON format is read from the local file system and is sent to the client in CSV
format, by using a function similar to JSON_CSV defined in assignment 1. If the URL contains a query string, then the table is filtered
accordingly.

Examples: assume the stored table corresponds to the following JSON array:
```json
[
    {"air quality":"yellow","temperature":20,"sea conditions":3,"city":"Genova"},
    {"city":"Milano","air quality":"red","temperature":10},
    {"city":"Torino","air quality":"red","temperature":8},
    {"city":"Imperia","air quality":"green","temperature":23,"sea conditions":2}
]
```
Then the following requests produce the corresponding output:
```bash
curl -X GET localhost:8080/weather
AIR QUALITY,TEMPERATURE,SEA CONDITIONS,CITY
yellow,20,3,Genova
red,10,,Milano
red,8,,Torino
green,23,2,Imperia

curl -X GET localhost:8080/weather?air%20quality=red ## matches rows with 'air quality'=red
CITY,AIR QUALITY,TEMPERATURE
Milano,red,10
Torino,red,8

curl -X GET "localhost:8080/weather?air%20quality=red&temperature=10" ## matches rows with 'air quality'=red and temperature=10
CITY,AIR QUALITY,TEMPERATURE
Milano,red,10
```
*Remark*: parameters of the query string are formatted before matching, as done for JSON_CSV in assignment 1, so that keys of the JSON object and parameters in the query string are case insensitive and spaces are not significant. 

To process query strings use [`url.parse`](https://nodejs.org/api/url.html#urlparseurlstring-parsequerystring-slashesdenotehost).

#### POST requests with URL `/JSON_CSV`
The posted data is assumed to be a JSON array and the server sends back its conversion in CSV format, similarly as done in assignment 1.

Example: if we assume that file `weather.json` contains the json array as in the example above, then
the following request produces the corresponding output:
```bash
curl -X POST localhost:8080/JSON_CSV -d @weather.json
AIR QUALITY,TEMPERATURE,SEA CONDITIONS,CITY
yellow,20,3,Genova
red,10,,Milano
red,8,,Torino
green,23,2,Imperia
```

Try to properly manage all possible errors, including illegal URL and methods different from GET and POST.
