'use strict';
const {createServer} = require('http');
const {URL} = require('url'); // url.parse deprecated for security reasons, replaced with new URL(req.url, `http://${req.headers.host}`)
const weather = require('./weather.json');

function toCSV(data, queryObject){
    // create the array of columns
    const columns = new Set();
    data.forEach(function(object, index, array){
        for(let property in object)
            columns.add(property);
    });
    // create the header
    let iterator = columns[Symbol.iterator]();
    let header = [];
    for(let result = iterator.next(); !result.done; result = iterator.next())
        header.push(result.value.toUpperCase());    
    let rows = [];
    rows.push(header.join(','));
    
    // create the rows
    data.forEach(function(object, index, array){
        let row = [];
        let couldPush = true;
        if(queryObject !== null){ // if there is a query string
			for (const [k, v] of queryObject.entries()) {
				if(object[k.toLowerCase()] === undefined) // if the parameter doesn't exist
					return header; // return just the header
				if (object[k.toLowerCase()].toString() !== v)
						couldPush = false;
			}
		}
        if(couldPush){
			columns.forEach(function(value){
				row.push(object[value]);
			});
			rows.push(row.join(','));
		}
    });
    return rows.join('\n');
}

 

const s=createServer(
    (req,res) => {
	
    if(req.method == "GET"){
		try {
			const reqUrl = new URL(req.url, `http://${req.headers.host}`); // extract the query string
    		const queryObject = reqUrl.searchParams; 
			res.writeHead(200, {"Content-Type": "application/json"});
        	res.end(`${JSON.stringify(toCSV(weather, queryObject)).replace(/\\n/g, '\n')}\n`); // send the csv version of the json file and filter the rows
			console.log('Http request sent by the server');
		}catch (err) {
			res.writeHead(400, {"Content-Type": "application/json"});
	        res.end(`${JSON.stringify({ error: err.message })}\n`);
		}
	}
	else if(req.method == "POST"){
		req.on('data', chunk => { // read data from the post request
	      chunks.push(chunk);
	    });
	    req.on('end', () => {
	      console.log('No more data to read from the post request');
	      try {
	        let data = JSON.parse(chunks.join('')); // join the pieces of the json string from the post request and parse it to a json object			
			res.writeHead(200, {"Content-Type": "application/json"}); 
        	res.end(`${JSON.stringify(toCSV(data, null)).replace(/\\n/g, '\n')}\n`); // transform the json to a csv format and put it inside the request
	        console.log('Http request sent by the server');
		  }catch (err) {
	        res.writeHead(400, {"Content-Type": "application/json"});
	        res.end(`${JSON.stringify({ error: err.message })}\n`);
		  }
	    });
	    const chunks = [];
	}
	else {
		res.writeHead(405, {"Content-Type": "application/json"});
		res.end("Method Not Allowed\n");
	}
});

 

s.listen(8080);
