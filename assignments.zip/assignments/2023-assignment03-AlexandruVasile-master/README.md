[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10603753&assignment_repo_type=AssignmentRepo)
# Assignment 3

## Node.js: event emitters

### Exercise 1
Complete file `exercise1.js` to define from scratch class `Reader`  to create readers  **without using** module `async`.
A reader opens a file, reads it into chunks of data until its end, and then closes it.

All I/O operations performed by the reader are **asynchronous**.

For simplicity a reader can only read a single file and cannot be reset to read other files.

Class `Reader` extends `EventEmitter` and supports events with the following types and arguments:

### Event type: `'open'` with no arguments

Emitted when the reader's file has been opened.

### Event type: `'data'`with two arguments

* argument `buf <Buffer>`. The buffer where the chunk of read data has been stored. 
* argument `bytes <integer>`. The size in bytes of the chunk of read data. 

Emitted whenever the reader has acquired a chunk of data from its file.

### Event type: `'close'` with no arguments

Emitted when the reader has finished reading the file and the corresponding file descriptor has been closed.

### Event type: `'error'`with one argument

* argument `err <Error>`

Emitted with the corresponding error object `err` as soon as an I/O operation of the reader has failed. In this case the reader tries to close the file
and no other events will be emitted. 

Class `Reader` defines the following constructors/methods.

### new Reader([size])

* `size <integer>`. The desired optional length of the reader's buffer. The default size is `2**4` bytes.

  Creates a new reader with an allocated buffer of `size` bytes.
  
### reader.readFile(path)

* `path <string>`. The path of the file associated with the reader.

  The reader starts reading the file identified by `path`: tries to open the file, then sequentially reads all chunks in its buffer, and finally closes it. 
  
Calling `readFile()` twice on the same reader  has no effect.
  
This is a simple example of use of `Reader`:

```js
const r=new Reader();
r.readFile(process.argv[2]||'test.txt');
r.once('error',console.error);
r.once('open',()=>console.log('opened'));
r.on('data',(bytes,buf)=>console.log(buf.toString('utf8',0,bytes)));
r.once('close',()=>console.log('closed'));
```
**Important remark**: listeners can be safely registered after calling `r.readFile()` because all I/O operations of the reader are asynchronous.

### Exercise 2 

Try to solve exercise 1 **by using** [`async.doWhilst`](https://caolan.github.io/async/v3/docs.html#doWhilst) and  [`async.waterfall`](https://caolan.github.io/async/v3/docs.html#waterfall).
