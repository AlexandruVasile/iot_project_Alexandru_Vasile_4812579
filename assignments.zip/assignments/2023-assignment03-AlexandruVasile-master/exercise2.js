'use strict';

const EventEmitter = require('events');
const { open, read, close } = require('fs');
const BUFF_SIZE = 2 ** 4;

class Reader extends EventEmitter {
    // to be completed
    constructor(buffer_size) {
    	super();
    	this.buffer = Buffer.alloc(buffer_size==undefined ? BUFF_SIZE : buffer_size);
    	this.alreadyReadAFile = false;
	}
    
    handle_error(err){
    	console.log("Teniamo un errore");
    	this.emit('error');
    }
    
    readFile(file){
		if(this.alreadyReadAFile) // such that we can't read more than one file
			return;
		this.alreadyReadAFile = true;
    	console.log(file);
		
    	open(file, 'r', (err, fd) => {
    		if(err){
				this.handle_error(err);
			}
    		else{
				this.emit('open'); 
    			this.leggiData(fd);
			}
    	});
    }
    
    leggiData(fd){
    	read(fd, {buffer: this.buffer}, (err, bytesRead, buffer) => { 
    		if (err){
				this.handle_error(err);
			}
    		if(bytesRead>0){ 
				this.emit('data', bytesRead, buffer);
				this.leggiData(fd); 
			}
    		else{ 
				close(fd, (err) =>{ 
                	if (err) {
						this.handle_error(err);
					}
					else {
						this.emit('close');
					}  
          		});
    		}
        });
    }
}

const r = new Reader();

r.readFile(process.argv[2] || 'test.txt');
r.once('error', console.error);
r.once('open', () => console.log('opened'));
r.on('data', (bytes, buf) => console.log(buf.toString('utf8', 0, bytes)));
r.once('close', () => console.log('closed'));
r.readFile(process.argv[2] || 'test.txt');
