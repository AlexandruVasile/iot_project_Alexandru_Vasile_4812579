'use strict';

function stringify(value) {
    function replacer(k, v) {
        if (typeof v === 'object') 
        {
            if( Array.isArray(v))
                return v;
            // if v is not an array but an object
            else {
                // then create an version of the object where the keys of the properties are uppercased 
                let new_obj = {};
                for(let property in v) {
                    if(typeof v[property] === 'string' || typeof v[property] === 'number')
                        new_obj[property.toUpperCase()] = v[property];
                }
                // replace the new object with the older one
                return new_obj;
            }     
        }
        return v;
    }
    return JSON.stringify(value, replacer);
}

let a=[{blob:Symbol(),city:'Milano',air_quality:'red',temperature:10},{air_quality:'yellow','temperature':20,'sea_conditions':3,city:'Genova',fun(x){return x},und:undefined}];
a.prop='prop';
console.log(stringify(a)); // prints [{"CITY":"Milano","AIR_QUALITY":"red","TEMPERATURE":10},{"AIR_QUALITY":"yellow","TEMPERATURE":20,"SEA_CONDITIONS":3,"CITY":"Genova"}]
