'use strict';

function replacer(k,v){
    console.log(`key:${k} value:${v.toString()}`);
    return v;
}

JSON.stringify({x:1,y:{v:0,d:true}},replacer);
console.log('*********');
JSON.stringify([{city:'Milano',air_quality:'red',temperature:10},{air_quality:'yellow','temperature':20,'sea_conditions':3,city:'Genova'}],replacer);

