'use strict';
const data = require('./weather.json');

function toCSV(data){
    // to be completed 

    // create the array of columns
    const columns = new Set();
    data.forEach(function(object, index, array){
        for(let property in object)
            columns.add(property);
    });
    
    // create the header
    let iterator = columns[Symbol.iterator]();
    let header = [];
    for(let result = iterator.next(); !result.done; result = iterator.next())
        header.push(result.value.toUpperCase());
    console.log(header.join(','));

    // create the rows
    data.forEach(function(object, index, array){
        let row = [];
        columns.forEach(function(value){
            row.push(object[value]);
        });
        console.log(row.join(","));
    });
}

console.log(toCSV(data));
