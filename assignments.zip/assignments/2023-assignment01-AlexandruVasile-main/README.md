[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10458642&assignment_repo_type=AssignmentRepo)
# Assignment 1
## JavaScript  

### Exercise 1
The behavior of `JSON.stringify` can be modified by passing a *replacer* function as second argument
(see the <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify">documentation</a> for more
details).

As an example of use, see file `stringify.js` where the replacer function does not affect the returned JSON string, but simply prints on the standard output the keys and values that are considered by 'JSON.stringify' during the traversal of the object. 

Complete file `exercise1.js` by defining a `replacer` function so that `stringify(value)` has the same behavior as `JSON.stringify`
but converts property keys in upper case. 

After completion, the execution of `node exercise1.js` should print
```js
[{"CITY":"Milano","AIR_QUALITY":"red","TEMPERATURE":10},{"AIR_QUALITY":"yellow","TEMPERATURE":20,"SEA_CONDITIONS":3,"CITY":"Genova"}]
```

### Exercise 2
Complete file `exercise2.js` by defining a `replacer` so that `stringify(o,...kept_keys)` has the same behavior as `JSON.stringify` but consider only
property keys included in the rest parameter `...kept_keys` in case of non-array objects. 

After completion, the execution of `node exercise2.js` should print
```js
[{"city":"Milano","temperature":10},{"temperature":20,"city":"Genova"}]
{"city":"Genova","temperatures":[23,23,22,20,18]}
```
### Exercise 3
Complete file `exercise3.js` by defining function `toCSV(data)` which converts an array of objects into a CSV table. Each element
in the array `data` corresponds to a single row where the own properties of the objects are column values.
For simplicity, the function emits the result on the standard output,
with the comma `','` and the newline as separators for columns and rows, respectively.
The first emitted row is the header of the table, with the keys of all properties. Property keys are formatted as follows: all letters are converted to upper case, while white spaces used as separators are trimmed to single spaces; you can tacitly assume that such formatting is free from name clashes. 

After completion, the execution of `node exercise3.js` should print
```bash
AIR QUALITY,TEMPERATURE,SEA CONDITIONS,CITY
yellow,20,3,Genova
red,10,,Milano
red,8,,Torino
green,23,2,Imperia
```
corresponding to the table
<table cellspacing="0" border="0">
	<colgroup width="118"></colgroup>
	<colgroup width="138"></colgroup>
	<colgroup width="156"></colgroup>
	<colgroup width="70"></colgroup>
	<tr>
		<td height="21" align="left">AIR QUALITY</td>
		<td align="left">TEMPERATURE</td>
		<td align="left">SEA CONDITIONS</td>
		<td align="left">CITY</td>
	</tr>
	<tr>
		<td height="21" align="left">yellow</td>
		<td align="right" sdval="20" sdnum="1033;">20</td>
		<td align="right" sdval="3" sdnum="1033;">3</td>
		<td align="left">Genova</td>
	</tr>
	<tr>
		<td height="21" align="left">red</td>
		<td align="right" sdval="10" sdnum="1033;">10</td>
		<td align="left"><br></td>
		<td align="left">Milano</td>
	</tr>
	<tr>
		<td height="21" align="left">red</td>
		<td align="right" sdval="8" sdnum="1033;">8</td>
		<td align="left"><br></td>
		<td align="left">Torino</td>
	</tr>
	<tr>
		<td height="21" align="left">green</td>
		<td align="right" sdval="23" sdnum="1033;">23</td>
		<td align="right" sdval="2" sdnum="1033;">2</td>
		<td align="left">Imperia</td>
	</tr>
</table>

