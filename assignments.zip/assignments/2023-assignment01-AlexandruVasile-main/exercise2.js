'use strict'; 

function stringify(o,...kept_keys){
    // to be completed

    function replacer(k, v) {     
        // if the key is allowed
        if(kept_keys.includes(k)){
            // and if the relative value is an array
            if(Array.isArray(v)){
                // add its indexes in the allowed keys in order to stringify its values in the further process
                for (let i = 0; i < v.length; i++)
                    kept_keys.push(i.toString());
            }
            return v;
        }
        // if we have an object that is not part of a property
        if (typeof v === 'object' && k === "") {
            // and if it's an array
            if(Array.isArray(v)){
                // // add its indexes in the allowed keys 
                for (let i = 0; i < v.length; i++)
                    kept_keys.push(i.toString());
            }
            return v;
        }
        // otherwise if the key is not allowed then don't consider the relative element in the stringify process
        return undefined; 
    }
    return JSON.stringify(o,replacer);
}
console.log(stringify([{city:'Milano',air_quality:'red',temperature:10},{air_quality:'yellow','temperature':20,'sea_conditions':3,city:'Genova'}],'temperature','city')); // prints [{"city":"Milano","temperature":10},{"temperature":20,"city":"Genova"}]
console.log(stringify({ city: 'Genova', temperatures: [23, 23, 22, 20, 18] }, 'city', 'temperatures')); // prints {"city":"Genova","temperatures":[23,23,22,20,18]}
